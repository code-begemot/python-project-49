### Hexlet tests and linter status:
[![Actions Status](https://github.com/code-begemot/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/code-begemot/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/5fbae6106009f37ac2a8/maintainability)](https://codeclimate.com/github/code-begemot/python-project-49/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/5fbae6106009f37ac2a8/test_coverage)](https://codeclimate.com/github/code-begemot/python-project-49/test_coverage)
[![asciicast](https://asciinema.org/a/624789.svg)](https://asciinema.org/a/624789)
