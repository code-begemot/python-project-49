from brain_games.game_logic import game_logic
import brain_games.games.prime


def main():
    game_logic(brain_games.games.prime)


if __name__ == "__main__":
    main()
