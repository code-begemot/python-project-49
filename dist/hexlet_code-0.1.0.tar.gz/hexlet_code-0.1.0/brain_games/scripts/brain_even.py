from brain_games.game_logic import game_logic
import brain_games.games.even


def main():
    game_logic(brain_games.games.even)


if __name__ == "__main__":
    main()
